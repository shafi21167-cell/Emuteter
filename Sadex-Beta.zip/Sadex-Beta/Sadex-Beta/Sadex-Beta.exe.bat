@echo off
title Sadex Beta Engine Launcher
color 0A
echo Launching Sadex Beta Non-VT Emulator Architecture...
python Sadex_Multi_Manager.py
pause
